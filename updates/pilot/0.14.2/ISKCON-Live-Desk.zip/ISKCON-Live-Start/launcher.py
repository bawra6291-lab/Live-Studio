"""Windows host for Live Desk. Run with the same Python used for the old app."""
import os, sys, json, socket, threading, webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox
from urllib.parse import quote
from config import BASE
from core import atomic_json
from dashboard import Controller, DashboardServer, lan_addresses
from desktop_host import DesktopHost
from desktop_window import DesktopWindow
from windows_identity import ICON, set_process_identity, brand_window

class Launcher:
    def __init__(self, root):
        self.root=root; self.closing=False; self.mobile=None; self.updates_dialog=None
        root.title('Live Desk • Development preview'); root.geometry('700x820');root.minsize(670,780)
        root.configure(bg='#f5f4ef')
        root.iconbitmap(default=str(ICON))
        self.controller=Controller()
        self.host=DesktopHost();self.controller.desktop_host=self.host
        self.controller.remote.start();self.controller.monitor.start();self.controller.social.start()
        from queue import SimpleQueue
        from tray import Tray
        self.tray_events=SimpleQueue();self.tray=Tray(self.tray_events.put);self.tray.start()
        self.controller.open_updates=lambda:self.host.submit({'action':'updates'})
        self.server=DashboardServer(('127.0.0.1',8865),self.controller)
        self.controller.desktop_url='http://127.0.0.1:8865'
        threading.Thread(target=self.server.serve_forever,daemon=True).start()
        self.pref_path=BASE/'dashboard.json'
        self.prefs=json.loads(self.pref_path.read_text('utf-8')) if self.pref_path.exists() else {}
        self.desktop=DesktopWindow(BASE,self.dashboard_url,self.open_browser,self.controller.log)
        self.desktop_setup_worker=None
        style=ttk.Style();style.theme_use('clam')
        style.configure('TButton',font=('Segoe UI',10),padding=10,background='#e5a473',foreground='#243b32')
        style.configure('TCombobox',padding=8)
        header=tk.Frame(root,bg='#193d36',padx=30,pady=26);header.pack(fill='x')
        tk.Label(header,text=self.controller.cfg['workspace_name'],font=('Segoe UI',10,'bold'),fg='#b9ccba',bg='#193d36').pack(anchor='w')
        tk.Label(header,text='Live Desk',font=('Segoe UI',28,'bold'),fg='#fff5e6',bg='#193d36').pack(anchor='w',pady=(6,3))
        tk.Label(header,text='Your livestream PC. Connected to your phone.',font=('Segoe UI',11),fg='#c4d0bb',bg='#193d36').pack(anchor='w')
        body=tk.Frame(root,bg='#f5f4ef',padx=30,pady=20);body.pack(fill='both',expand=True)
        app_row=tk.Frame(body,bg='#f5f4ef');app_row.pack(fill='x')
        ttk.Button(app_row,text='Open dashboard  ↗',command=self.open_dashboard).pack(side='left',fill='x',expand=True,padx=(0,8))
        ttk.Button(app_row,text='App updates',command=self.open_updates).pack(side='right')
        obs_row=tk.Frame(body,bg='#f5f4ef');obs_row.pack(fill='x',pady=(10,0))
        self.obs_button=ttk.Button(obs_row,text='Open / Show OBS',command=self.open_obs)
        self.obs_button.pack(side='left',fill='x',expand=True,padx=(0,8))
        ttk.Button(obs_row,text='Set up administrator OBS',command=self.setup_obs_admin).pack(side='right')
        self.obs_status=tk.StringVar(value='OBS opens on this desktop. Administrator setup is needed only once.')
        tk.Label(body,textvariable=self.obs_status,font=('Segoe UI',9),fg='#49644e',bg='#f5f4ef',wraplength=620,justify='left').pack(anchor='w',pady=(6,0))
        self.status=tk.StringVar(value='Dashboard running on this PC.')
        tk.Label(body,textvariable=self.status,font=('Segoe UI',10),fg='#49644e',bg='#f5f4ef',wraplength=595,justify='left').pack(anchor='w',pady=(12,18))
        tk.Label(body,text='MOBILE ACCESS',font=('Segoe UI',10,'bold'),fg='#53674f',bg='#f5f4ef').pack(anchor='w')
        tk.Label(body,text='Use the same trusted Wi-Fi as this PC.',font=('Segoe UI',10),fg='#7c8876',bg='#f5f4ef').pack(anchor='w',pady=(6,10))
        addresses=lan_addresses();self.network=tk.StringVar(value=self.prefs.get('ip') if self.prefs.get('ip') in addresses else (addresses[0] if addresses else ''))
        row=tk.Frame(body,bg='#f5f4ef');row.pack(fill='x')
        self.network_box=ttk.Combobox(row,textvariable=self.network,values=addresses,state='readonly',width=23);self.network_box.pack(side='left',fill='x',expand=True,padx=(0,10))
        self.mobile_button=ttk.Button(row,text='Enable mobile access',command=self.toggle_mobile);self.mobile_button.pack(side='right')
        self.phone_url=tk.StringVar(value='Mobile access is off.')
        tk.Entry(body,textvariable=self.phone_url,state='readonly',readonlybackground='#edf1e6',fg='#2f5942',relief='flat',font=('Consolas',13),justify='center').pack(fill='x',ipady=13,pady=(13,12))
        code_row=tk.Frame(body,bg='#f5f4ef');code_row.pack(fill='x')
        tk.Label(code_row,text='Pairing code:',font=('Segoe UI',10),bg='#f5f4ef',fg='#52634d').pack(side='left')
        self.code=tk.StringVar(value=self.server.pair_code)
        tk.Entry(code_row,textvariable=self.code,state='readonly',show='•',readonlybackground='#f5f4ef',relief='flat',font=('Consolas',12),width=20).pack(side='left',padx=12)
        ttk.Button(code_row,text='Show code',command=self.show_code).pack(side='right')
        tk.Label(body,text='Open the phone address in Chrome/Safari, then enter the code.\nLocal HTTP connection: trusted private Wi-Fi only; no internet port forwarding.',font=('Segoe UI',9),bg='#f5f4ef',fg='#7c8876',justify='left',wraplength=590).pack(anchor='w',pady=(12,18))
        row=tk.Frame(body,bg='#f5f4ef');row.pack(fill='x')
        ttk.Button(row,text='Start with Windows',command=self.startup).pack(side='left',padx=(0,8))
        ttk.Button(row,text='Remove startup',command=self.remove_startup).pack(side='left',padx=(0,8))
        ttk.Button(row,text='Settings / logs',command=lambda:os.startfile(BASE)).pack(side='left')
        tk.Label(body,text='Closing a dashboard or this recovery window keeps automation running.\nUse PC controls → Quit Live Desk to stop the background app.',font=('Segoe UI',10),bg='#f5f4ef',fg='#52634d',justify='left').pack(anchor='w',pady=(18,0))
        root.protocol('WM_DELETE_WINDOW',root.withdraw)
        # A transient wake request, restored when the app exits. Does not unlock Windows.
        import ctypes
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
        if self.prefs.get('mobile') and self.network.get()==self.prefs.get('ip'):
            self.enable_mobile()
        if self.controller.cfg.get('armed'):self.controller.run('arm')
        root.after(500,self.open_dashboard);root.after(1000,self.update_status)
        root.after(100,self.drain_host)
    def dashboard_url(self):
        return self.controller.desktop_url+'/#pair='+quote(self.server.pair_code)
    def open_dashboard(self):
        if self.closing:return
        if self.prefs.get('dashboard_mode','desktop')=='browser':self.open_browser()
        else:self.desktop.open()
    def open_browser(self):
        if not webbrowser.open(self.dashboard_url()):
            self.root.deiconify()
            self.controller.log('Default browser could not open. Recovery controls are available in the Windows launcher.')
    def drain_host(self):
        if self.closing:return
        result=self.host.drain(self.pc_action)
        if result:self.controller.log(result)
        self.root.after(100,self.drain_host)
    def pc_action(self,action,ip):
        if self.closing or self.controller.maintenance:raise ValueError('App is closing or updating.')
        if action=='obs':
            if self.obs_button.instate(['disabled']):raise ValueError('OBS action already in progress.')
            self.open_obs();return None  # The worker reports completion in obs_finished.
        if action=='obs-admin':
            os.startfile(str(Path(__file__).with_name('SETUP-OBS-ADMIN.cmd')))
            return 'OBS administrator setup opened. Approve Windows UAC on this PC.'
        if action=='obs-layout':
            if self.controller.armed or self.controller.mode:
                raise ValueError('Pause automation and finish the current operation first.')
            os.startfile(str(Path(__file__).with_name('SETUP-OBS-LAYOUT.cmd')))
            return 'Layout protection setup opened. Finish active lives and close OBS normally before installing; approve Windows UAC on this PC.'
        if action=='startup':return self.startup(notify=False)
        if action=='startup-remove':return self.remove_startup(notify=False)
        if action=='logs':
            os.startfile(BASE);return 'Settings and logs folder opened on this PC.'
        if action=='mobile-on':
            if self.mobile:raise ValueError('Mobile access is already enabled.')
            self.network.set(ip);self.enable_mobile(notify=False)
            return 'Wi-Fi mobile access enabled: '+self.phone_url.get()
        if action=='mobile-off':
            if self.mobile:self.toggle_mobile()
            return 'Wi-Fi mobile access disabled. Internet remote access is unchanged.'
        if action=='launcher':
            self.root.deiconify();self.root.lift();return 'Recovery launcher opened on this PC.'
        if action in ('desktop','browser'):
            self.prefs['dashboard_mode']=action;atomic_json(self.pref_path,self.prefs)
            self.open_dashboard()
            return 'Dashboard preference saved: '+action+'. Automation is unchanged.'
        if action=='desktop-setup':
            self.setup_desktop();return None
        if action=='updates':
            self.open_updates();return 'Update controls opened on this PC.'
        if action=='quit':
            if self.controller.updates.snapshot()['busy'] or (self.updates_dialog and self.updates_dialog.busy):raise ValueError('Update in progress.')
            self.host.update(available=False)
            # Let the HTTP response and final status leave before closing the server.
            self.root.after(500,lambda:self.close(confirmed=True))
            return 'Live Desk is closing. Future automation and phone control will stop; existing live continues.'
        raise ValueError('Unsupported PC action.')
    def setup_desktop(self):
        # Reserve the host slot through completion; updates and Quit must wait.
        from desktop_window import install_runtime
        with self.controller.lock:
            self.controller.require_idle()
            if self.controller.armed:raise ValueError('Pause automation before desktop setup.')
        def work():
            try:
                from updater import check_obs_idle
                check_obs_idle(self.controller)
                install_runtime(BASE)
                result='Desktop component installed. Opening Live Desk; if WebView2 Runtime is missing, the browser fallback stays available.'
                success=True
            except Exception:
                result='Desktop setup could not finish. Finish all OBS outputs, check internet and Python pip, then retry. The browser dashboard remains available.'
                success=False
            if not self.closing:self.root.after(0,lambda:self.desktop_setup_finished(success,result))
        self.desktop_setup_worker=threading.Thread(target=work,daemon=True)
        self.desktop_setup_worker.start()
        self.host.update(message='Installing desktop component. This can take several minutes; browser controls remain available.')
    def desktop_setup_finished(self,success,result):
        self.controller.log(result);self.host.finish(result)
        if success:
            self.prefs['dashboard_mode']='desktop';atomic_json(self.pref_path,self.prefs)
            self.open_dashboard()
    def open_updates(self):
        if self.closing:return
        if self.updates_dialog:self.updates_dialog.window.lift();return
        from updates_ui import UpdatesDialog
        self.updates_dialog=UpdatesDialog(self)
    def setup_obs_admin(self):
        try:os.startfile(str(Path(__file__).with_name('SETUP-OBS-ADMIN.cmd')))
        except OSError:messagebox.showerror('OBS setup','Open SETUP-OBS-ADMIN.cmd from the extracted app folder.')
    def open_obs(self):
        with self.controller.lock:
            if self.controller.maintenance:return
            exe=self.controller.cfg['obs_exe']
        self.obs_button.configure(state='disabled');self.obs_status.set('Opening / showing OBS…')
        def work():
            from obs_windows import open_obs, OBSLaunchError
            try:result=open_obs(exe)
            except OBSLaunchError as exc:result=str(exc)
            self.controller.log(result)
            if not self.closing:self.root.after(0,lambda:self.obs_finished(result))
        threading.Thread(target=work,daemon=True).start()
    def obs_finished(self,result):
        self.obs_status.set(result);self.obs_button.configure(state='normal')
        self.host.finish(result)
    def show_code(self):
        messagebox.showinfo('Pair this phone',f'Pairing code (case-sensitive):\n\n{self.server.pair_code}\n\nPhone codes expire after 30 minutes. Generate a fresh code in the dashboard’s Mobile access panel.\nShare only with the intended operator or viewer.')
    def enable_mobile(self,notify=True):
        ip=self.network.get()
        if ip not in lan_addresses():
            if not notify:raise ValueError('No matching local network address.')
            messagebox.showerror('Network','No matching local network address. Connect the PC to Wi-Fi/Ethernet and reopen the app.');return
        try:
            mobile=DashboardServer((ip,8866),self.controller,self.server.pair_code)
            mobile.pair_expires=self.server.pair_expires;mobile.pair_role=self.server.pair_role
            mobile.allowed_hosts={ip}
            threading.Thread(target=mobile.serve_forever,daemon=True).start();self.mobile=mobile
            with self.controller.lock:
                self.controller.mobile_enabled=True;self.controller.mobile_urls=[f'http://{ip}:8866']
            self.phone_url.set(f'http://{ip}:8866');self.mobile_button.configure(text='Disable mobile access');self.network_box.configure(state='disabled')
            self.prefs.update(mobile=True,ip=ip);atomic_json(self.pref_path,self.prefs)
        except OSError:
            if not notify:raise
            messagebox.showerror('Mobile access','Could not open port 8866 on this address. Close another copy or choose the correct network.')
    def toggle_mobile(self):
        if self.mobile:
            self.mobile.shutdown();self.mobile.server_close();self.mobile=None
            with self.controller.lock:self.controller.mobile_enabled=False;self.controller.mobile_urls=[]
            self.prefs['mobile']=False;atomic_json(self.pref_path,self.prefs)
            self.phone_url.set('Mobile access is off.');self.mobile_button.configure(text='Enable mobile access');self.network_box.configure(state='readonly')
        else:self.enable_mobile()
    def startup_path(self):return Path(os.environ['APPDATA'])/'Microsoft/Windows/Start Menu/Programs/Startup/ISKCON-Live-Start.lnk'
    def startup(self,notify=True):
        try:
            import win32com.client
            shortcut=win32com.client.Dispatch('WScript.Shell').CreateShortCut(str(self.startup_path()))
            exe=Path(sys.executable);gui=exe.with_name('pythonw.exe')
            shortcut.Targetpath=str(gui if gui.exists() else exe)
            shortcut.Arguments='-E -s "'+str(Path(__file__).with_name('desktop_start.py').resolve())+'"'
            shortcut.WorkingDirectory=str(Path(__file__).parent.resolve())
            shortcut.IconLocation=str(ICON)+',0';shortcut.save()
            if notify:messagebox.showinfo('Startup saved','Live Desk will open after Windows login. This replaces the old app startup shortcut. Keep this folder in its current location.')
            return 'Start with Windows enabled. Keep the app folder in its current location.'
        except Exception:
            if not notify:raise
            messagebox.showerror('Startup','Could not create shortcut. Install requirements with the same Python used to run this app.')
    def remove_startup(self,notify=True):
        try:
            self.startup_path().unlink(missing_ok=True)
            if notify:messagebox.showinfo('Startup removed','Automatic app launch removed. Current automation is unchanged.')
            return 'Start with Windows disabled. Current automation is unchanged.'
        except OSError:
            if not notify:raise
            messagebox.showerror('Startup','Could not remove shortcut. Check Windows permissions.')
    def update_status(self):
        self.code.set(self.server.pair_code)
        if self.closing:return
        self.desktop.poll()
        with self.controller.lock:self.status.set(self.controller.message)
        while not self.tray_events.empty():
            event=self.tray_events.get()
            if event=='dashboard':self.open_dashboard()
            elif event=='pause' and not self.controller.maintenance:self.controller.pause()
            elif event=='quit':self.close()
        if self.controller.updates.exit_ready.is_set():
            self.closing=True;self.tray.close();self.controller.shutdown();self.wait_close();return
        self.tray.update(self.controller.armed)
        self.host.update(tray_available=self.tray.available,addresses=lan_addresses(),startup=self.startup_path().exists(),
                         dashboard_mode=self.prefs.get('dashboard_mode','desktop'),desktop_message=self.desktop.message)
        self.root.after(1000,self.update_status)
    def close(self,confirmed=False):
        if self.desktop_setup_worker and self.desktop_setup_worker.is_alive():
            messagebox.showinfo('Desktop setup','Wait for desktop setup to finish.');return
        if self.controller.updates.snapshot()['busy'] or (self.updates_dialog and self.updates_dialog.busy):
            messagebox.showinfo('Update in progress','Wait for the update operation to finish.');return
        if not confirmed and not messagebox.askyesno('Close Live Desk?','Future starts, scheduled endings, camera actions and phone control will stop. Existing broadcasts continue. Close the app?'):return
        self.closing=True;self.tray.close();self.controller.shutdown();self.status.set('Waiting for the current operation to finish…')
        self.wait_close()
    def wait_close(self):
        if self.controller.social.busy:self.root.after(300,self.wait_close);return
        if self.controller.worker and self.controller.worker.is_alive():self.root.after(300,self.wait_close);return
        worker=self.controller.updates.worker
        if worker and worker.is_alive():self.root.after(300,self.wait_close);return
        self.desktop.close()
        for server in [self.mobile,self.server]:
            if server:server.shutdown();server.server_close()
        import ctypes
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        self.root.destroy()

def main():
    if os.name!='nt':raise SystemExit('Run launcher.py on the Windows livestream PC.')
    set_process_identity()
    # The installer checks this named mutex before replacing the bundled runtime.
    import ctypes
    from ctypes import wintypes
    ctypes.windll.kernel32.CreateMutexW.restype=wintypes.HANDLE
    installation_mutex=ctypes.windll.kernel32.CreateMutexW(None,False,'LiveDeskController-v1')
    root=tk.Tk();root.withdraw();instance=socket.socket()
    # Tk's shell window is the parent of the widget HWND.
    root.update_idletasks()
    import win32gui
    try:brand_window(win32gui.GetParent(root.winfo_id()) or root.winfo_id())
    except Exception:pass  # Shell branding must never prevent the host starting.
    try:instance.bind(('127.0.0.1',47639))
    except OSError:
        try:
            with socket.create_connection(('127.0.0.1',47639),timeout=2) as existing:existing.sendall(b'open')
        except OSError:messagebox.showinfo('App already running','Another controller is running. Open http://127.0.0.1:8865 in your browser, or close the old app first.')
        root.destroy();return
    try:
        launcher=Launcher(root)  # The designed dashboard is the primary window.
        instance.listen(4);instance.settimeout(1)
        # Only a fixed local reopen request; no commands, URLs or credentials.
        reopen=threading.Event()
        def listen():
            while not launcher.closing:
                try:
                    conn,_=instance.accept()
                    with conn:
                        conn.settimeout(1)
                        if conn.recv(16)==b'open':reopen.set()
                except (OSError,socket.timeout):continue
        threading.Thread(target=listen,daemon=True).start()
        def check_reopen():
            if launcher.closing:return
            if reopen.is_set():reopen.clear();launcher.open_dashboard()
            root.after(250,check_reopen)
        root.after(250,check_reopen)
        ready=os.environ.pop('ISKCON_UPDATE_READY',None)
        if ready:Path(ready).write_text('ready',encoding='utf-8')
        root.mainloop()
    except Exception as exc:
        messagebox.showerror('Could not open Live Desk',f'{type(exc).__name__}: check requirements, saved settings and ports 8865/8866.\n\nIn this extracted folder run:\npy -m pip install -r requirements.txt\npy launcher.py')
        root.destroy()
    finally:instance.close()

if __name__=='__main__':main()
